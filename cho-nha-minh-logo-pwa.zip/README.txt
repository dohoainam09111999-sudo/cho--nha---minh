CHỢ NHÀ MÌNH – BỘ BIỂU TƯỢNG PWA

Tải toàn bộ 4 tệp trong thư mục này lên thư mục gốc (root) của GitHub repository, cùng cấp với index.html:
- icon-192.png
- icon-512.png
- apple-touch-icon.png
- manifest.webmanifest

Sau đó thêm các dòng sau vào phần <head> của index.html (nếu chưa có):
<link rel="manifest" href="/manifest.webmanifest">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<meta name="theme-color" content="#16833b">

Commit lên nhánh main và chờ Vercel deploy xong. Trên iPhone: xoá biểu tượng Chợ Nhà Mình cũ khỏi màn hình chính, mở website bằng Safari, Chia sẻ > Thêm vào MH chính.
