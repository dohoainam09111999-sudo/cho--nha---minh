# Chợ Nhà Mình – bản demo
Mở `index.html` bằng trình duyệt để xem website demo.

Có giao diện mua rau củ, tìm kiếm, lọc danh mục, giỏ hàng và mô phỏng đặt hàng.

Lưu ý: Đây là bản demo tĩnh. Đơn hàng không được gửi đến cửa hàng; chưa có quản lý đơn hàng, đồng bộ dữ liệu, đăng nhập hoặc thanh toán thật. Giá và sản phẩm là dữ liệu mẫu.
